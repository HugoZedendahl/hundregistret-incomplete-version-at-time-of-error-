public enum SortingAlgorithm {
        BUBBLE_SORT,
        QUICK_SORT
    }