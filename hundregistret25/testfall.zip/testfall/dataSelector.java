enum dataSelector{
        DOG_AGE,
        DOG_WEIGHT,
        DOG_TAILLENGTH
    }