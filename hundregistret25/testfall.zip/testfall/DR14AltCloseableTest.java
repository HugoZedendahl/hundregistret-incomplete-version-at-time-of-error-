import org.junit.jupiter.api.*;

/**
 * @author Henrik Bergström
 * @version
 */
public class DR14AltCloseableTest extends DR01Assertions {
	@Order(10)
	@Test
	@DisplayName("")
	public void test1() {
		assertTestTimesOut(() -> {
		});
	}

	@Order(20)
	@Test
	@DisplayName("")
	public void test2() {
		assertTestTimesOut(() -> {
		});
	}

	@Order(30)
	@Test
	@DisplayName("")
	public void test3() {
		assertTestTimesOut(() -> {
		});
	}

	@Order(40)
	@Test
	@DisplayName("")
	public void test4() {
		assertTestTimesOut(() -> {
		});
	}

	@Order(50)
	@Test
	@DisplayName("")
	public void test5() {
		assertTestTimesOut(() -> {
		});
	}

	@Order(60)
	@Test
	@DisplayName("")
	public void test6() {
		assertTestTimesOut(() -> {
		});
	}

	@Order(70)
	@Test
	@DisplayName("")
	public void test7() {
		assertTestTimesOut(() -> {
		});
	}

	@Order(80)
	@Test
	@DisplayName("")
	public void test8() {
		assertTestTimesOut(() -> {
		});
	}

	@Order(90)
	@Test
	@DisplayName("")
	public void test9() {
		assertTestTimesOut(() -> {
		});
	}

	@Order(100)
	@Test
	@DisplayName("")
	public void test10() {
		assertTestTimesOut(() -> {
		});
	}

	@Order(110)
	@Test
	@DisplayName("")
	public void test11() {
		assertTestTimesOut(() -> {
		});
	}

	@Order(120)
	@Test
	@DisplayName("")
	public void test12() {
		assertTestTimesOut(() -> {
		});
	}

	@Order(130)
	@Test
	@DisplayName("")
	public void test13() {
		assertTestTimesOut(() -> {
		});
	}

	@Order(140)
	@Test
	@DisplayName("")
	public void test14() {
		assertTestTimesOut(() -> {
		});
	}

}
